package FinalAssign;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class BMIClient 
{
	private Data message;
	private Socket connection;
	private ObjectOutputStream output;
	private ObjectInputStream input;
	private Scanner keyboard; 
	private double weight;
	private double height;
	private String bmiServer;

	public BMIClient(String host) 
	{
		bmiServer = host;

		System.out.print ("\nEnter the weight of the body (kg): ");
		keyboard = new Scanner(System.in);
		weight = keyboard.nextDouble();

		System.out.print("Enter the height of the body (metres): ");
		height = keyboard.nextDouble();

		message = new Data(weight, height);
	}	

	public void runClient()
	{
		try {
			connectToServer();
			getStreams();
			processConnection();
		}
		catch(EOFException eofExeption)
		{
			System.out.println("\nClient terminated connection!");
		}	
		catch(IOException ioException)
		{
			ioException.printStackTrace();
		}
		finally 
		{
			// closeConnection();
		}
	}

	private void connectToServer () throws IOException 
	{
		System.out.println("\nAttempting connection...\n");
		connection = new Socket(InetAddress.getByName(bmiServer), 8080);

		System.out.println("Connected to " + connection.getInetAddress().getHostName());
	}

	private void getStreams () throws IOException
	{
		output = new ObjectOutputStream(connection.getOutputStream());
		output.flush();

		input = new ObjectInputStream(connection.getInputStream());
	}	

	public void processConnection() throws IOException 
	{
		try {
			System.out.println("\nConnection successful");
			sendData(message);
			System.out.println("\nWaiting for server to finish processing...");
			message = (Data) input.readObject();
			System.out.println("\nObject received from server. Processing complete. \n");
			Double BMI = message.getBMI();
			String status = "";
			if (BMI > 30)
				status = "Obese";
			else if (BMI > 25 && BMI < 29.9)
				status = "Overweight";
			else if (BMI > 18.5 && BMI < 24.9)
				status = "Normal";
			else if (BMI < 18.5)
				status = "Underweight";
			System.out.printf("Your BMI is: %.2f", BMI);
			System.out.println(" (" + status + ")");
		}
		catch(ClassNotFoundException classNotFoundException)
		{
			System.out.println("\nUnknown Object type received");
		}
	}	

	public void closeConnection()
	{
		System.out.println("\nTerminating connection...\n");

		try {
			output.close();	
			input.close();	
			connection.close();
		}	
		catch(IOException ioException)
		{
			System.out.println("\nClient Disconnected \n");	
		}	
	}	

	private void sendData(Data message) 
	{
		try
		{	
			output.writeObject(message);
			output.flush();
			System.out.println("\nCLIENT >>> Sent the message to server. ");
		} 
		catch(IOException ioException) 
		{
			System.out.println("\nAn error occured writing object");
		}
	}
	public static void main(String args[]) 
	{
		BMIClient application;
		if(args.length == 0) 
			application = new BMIClient("127.0.0.1");
		else
			application = new BMIClient(args[0]);

		application.runClient();
	}	

}	
