package FinalAssign;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class BMIMultiThreadServer
{
	private ServerSocket server;
	private Socket connection;
	private int counter;
    private static ObjectOutputStream output;
	private static ObjectInputStream input;

	public BMIMultiThreadServer()
	{
		// initialize the count variable
		counter = 1;
	}

	public void runServer()
	{
		try {
			server = new ServerSocket(8080, 10);
            server.setReuseAddress(true);

			while(true) 
			{	
				try {
					waitForConnection();

                    ClientHandler clientSock = new ClientHandler(connection);

                    new Thread(clientSock).start();
				}	
				catch (EOFException eofExeption)
				{
					System.out.println("\nServer terminated connection!");
				}	
				finally 
				{
					// closeConnection();
					counter++;
				}	
			}
		}
		catch (IOException ioException) 
		{
			ioException.printStackTrace();
		}
	}

    private static class ClientHandler implements Runnable {
        private final Socket clientSocket;
        private Data message;
  
        // Constructor
        public ClientHandler(Socket socket)
        {
            this.clientSocket = socket;
        }
  
        public void run() {
            try {
                getStreams();
                processConnection();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }

        private void getStreams() throws IOException
        {
            output = new ObjectOutputStream(clientSocket.getOutputStream());
            output.flush();

            input = new ObjectInputStream(clientSocket.getInputStream());
        }

        public void processConnection () throws IOException 
        {
            try {
                System.out.println("\nConnection successful");

                message = (Data) input.readObject();	
                System.out.println("\nThe following message was received from the client: ");
                System.out.println("\nHeight: " + message.getHeight() + " metres");
                System.out.println("Weight: " + message.getWeight() + " kg");
            }
            catch(ClassNotFoundException classNotFoundException)
            {
                System.out.println("\nUnknown Object type received.");
            }
        
            calculateBMI(message);
            sendData(message);	
        }

        public static void calculateBMI(Data message) 
        {
            message.setBMI(message.getWeight() / (message.getHeight() * message.getHeight()));
        }

        private void sendData(Data message) 
        {
            try
            {	
                output.writeObject(message);
                output.flush();
                System.out.println("\nSERVER >>> Sent back the message to client\n");
            } 
            catch ( IOException ioException ) 
            {
                System.out.println("\nAn error occured writing object");
            }
        }
    }

	private void waitForConnection() throws IOException 
	{
		System.out.println("\nWaiting for connection...");
		connection = server.accept();
		System.out.println("\nConnection " + counter + " received from " + connection.getInetAddress().getHostName());
	}		

	public void closeConnection()
	{
		System.out.println("\nTerminating connection...\n");

		try {
			output.close();	
			input.close();	
			connection.close();
		}	
		catch (IOException ioException)
		{
			ioException.printStackTrace();	
		}	
	}
	public static void main(String args[])
	{
		//For MultiThread Server
		BMIMultiThreadServer application = new BMIMultiThreadServer();			
		application.runServer();
	}	

}

