package FinalAssign;

import java.io.Serializable;

public class Data implements Serializable 
{
	private double weight;
	private double height;
	private double bodyMassIndex;

	public Data ( double theWeight, double theHeight )
	{
		setWeight ( theWeight );
		setHeight ( theHeight );
	}	

	public void setWeight ( double theWeight ) 
	{
		weight = theWeight;
	}

	public void setHeight ( double theHeight ) 
	{
		height = theHeight;
	}
	
	public void setBMI ( double bmi )
	{
		bodyMassIndex = bmi;
	}	
	
	public double getBMI ( ) 
	{
		return bodyMassIndex;
	}

	public double getWeight ( )
	{
		return weight;
	}	

	public double getHeight () 
	{
		return height;
	}

}
