package FinalAssign;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class BMIServer 
{
	private Data message;
	private ServerSocket server;
	private Socket connection;
	private ObjectOutputStream output;
	private ObjectInputStream input;
	private int counter;

	public BMIServer()
	{
		// initialize the count variable
		counter = 1;
	}

	public void runServer()
	{
		try {
			server = new ServerSocket(8080, 10);

			while(true) 
			{	
				try {
					waitForConnection();
					getStreams();
					processConnection();
				}	
				catch (EOFException eofExeption)
				{
					System.out.println("\nServer terminated connection!");
				}	
				finally 
				{
					closeConnection();
					counter++;
				}	
			}
		}
		catch (IOException ioException) 
		{
			ioException.printStackTrace();
		}
		
	}
	private void waitForConnection() throws IOException 
	{
		System.out.println("Waiting for connection... \n");
		connection = server.accept();
		System.out.println("Connection " + counter + " received from " + connection.getInetAddress().getHostName());
	}	

	private void getStreams() throws IOException
	{
		output = new ObjectOutputStream(connection.getOutputStream());
		output.flush();

		input = new ObjectInputStream(connection.getInputStream());
	}

	public void processConnection () throws IOException 
	{
		try {
			System.out.println("\nConnection successful");

			message = (Data) input.readObject();	
			System.out.println("\nThe following message was received from the client:");
			System.out.println("\nHeight: " + message.getHeight() + " metres");
			System.out.println("Weight: " + message.getWeight() + " kg");
		}
		catch(ClassNotFoundException classNotFoundException)
		{
			System.out.println("\nUnknown Object type received.");
		}
	
		calculateBMI(message);
		sendData(message);	
	}	

	public void closeConnection()
	{
		System.out.println("\nTerminating connection...\n");

		try {
			output.close();	
			input.close();	
			connection.close();
		}	
		catch (IOException ioException)
		{
			ioException.printStackTrace();	
		}	
	}

    public static void calculateBMI(Data message) 
    {
		message.setBMI(message.getWeight() / (message.getHeight() * message.getHeight()));
    }

	private void sendData(Data message) 
	{
		try
		{	
			output.writeObject(message);
			output.flush();
			System.out.println("\nSERVER >>> Sent back the message to client");
		} 
		catch ( IOException ioException ) 
		{
			System.out.println("\nAn error occured writing object");
		}
	}
	public static void main(String args[])
	{
		
		BMIServer application = new BMIServer();			
		application.runServer();
	}	
}
